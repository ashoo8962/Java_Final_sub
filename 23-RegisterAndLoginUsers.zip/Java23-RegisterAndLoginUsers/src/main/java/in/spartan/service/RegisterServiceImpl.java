package in.spartan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.spartan.model.Login;
import in.spartan.model.Register;
import in.spartan.repo.IRegisterRepo;

@Service
public class RegisterServiceImpl implements IRegisterService {

	@Autowired
	private IRegisterRepo repo;
	
	@Override
	public String registerService(Register register) {
		Register reg = repo.save(register);
		return "Registered Successfully ";
	}

	@Override
	public String validateUser(Login login) {
		Integer user = repo.validateUser(login.getEmail(), login.getPassword());
		if(user>=1)
			return "matched";
		else
		    return "unmatched";
	}

}
