package in.ineuron.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class TestApp {
	
	public static int secondLargest(List<Integer> list) {
		List<Integer> collect = list.stream().sorted((num1,num2)->num2.compareTo(num1)).collect(Collectors.toList());
		return collect.get(1);
	}
	
	public static int secondSmallest(List<Integer> list) {

		List<Integer> collect = list.stream().sorted().collect(Collectors.toList());
		return collect.get(1);
		
	}
	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		List<Integer> list=new ArrayList<Integer>();
		System.out.println("Enter the size of list or elements to store");
		int size = scan.nextInt();
		for(int i=0;i<size;i++) {
			int num=scan.nextInt();
			list.add(num);
		}
		
		System.out.println("The second Largest element is:: "+TestApp.secondLargest(list));
		System.out.println("The second smallest element is:: "+TestApp.secondSmallest(list));
		
	}
	

}
