package in.spartan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import in.spartan.model.Employee;
import in.spartan.repo.IEmployeeRepo;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	
	@Autowired
	private IEmployeeRepo repo;

	@Override
	public List<Employee> getAllEmployeesBySorting(String order, String property) {
		Sort sort=Sort.by(((order=="asc")?Direction.ASC:Direction.DESC), property);
		return (List<Employee>) repo.findAll(sort);
		
	}

	@Override
	public Page<Employee> getAllEmployeesByPagination(Pageable pageable)
	{	
		return repo.findAll(pageable);
		}		
}

