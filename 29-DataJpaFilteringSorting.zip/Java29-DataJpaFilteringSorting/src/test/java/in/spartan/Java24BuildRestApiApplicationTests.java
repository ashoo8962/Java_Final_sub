package in.spartan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java24BuildRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
