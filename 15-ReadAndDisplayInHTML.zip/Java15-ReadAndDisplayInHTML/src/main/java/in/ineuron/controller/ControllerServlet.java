package in.ineuron.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dao.IStudentDao;
import in.ineuron.dao.StudentDaoImpl;
import in.ineuron.dto.Student;


@WebServlet("/select")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IStudentDao stdDao = new StudentDaoImpl();
			String sid = request.getParameter("sid");

			List<Student> students = stdDao.searchStudent();
			request.setAttribute("students", students);

			RequestDispatcher rd = null;
			rd = request.getRequestDispatcher("./display.jsp");
			rd.forward(request, response);


	}
}
