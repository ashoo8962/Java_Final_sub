package in.ineuron.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LogGenerator {
	
	@Pointcut("execution(public * in.ineuron.service.Calculation.*(..))")
	void service() {}
	
	@Before("service()")
	public void beforeCallInvoke(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        Object[] args = joinPoint.getArgs();
        System.out.println("INFO   :   Method called: " + methodName+"()");
        System.out.println("INFO   :   Input parameters: " + Arrays.toString(args));
    }
    
    @AfterReturning(pointcut = "service()", returning = "result")
    public void afterCallReturn(JoinPoint joinPoint, Object result) {
        String methodName = joinPoint.getSignature().getName();
        System.out.println("INFO   :   Method returned: " + methodName+"()");
        System.out.println("INFO   :   Output: " + result);
    }

}
