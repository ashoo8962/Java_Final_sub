package in.main;

import in.threads.SecondThread;

public class TestApp {
	
	public static void main(String[] args) {
		
		Thread thread=new Thread(new SecondThread());
		
		thread.start();
		
		System.out.println("Thread name::"+Thread.currentThread().getName());
		System.out.println("Even numbers between 1 to 10");
		for(int i=1;i<=10;i++) {
			if(i%2==0)
			   System.out.print(i+" ");
		}
		System.out.println();
	}

}
