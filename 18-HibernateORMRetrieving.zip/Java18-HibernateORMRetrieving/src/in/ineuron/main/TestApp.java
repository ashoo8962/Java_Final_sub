package in.ineuron.main;

import java.util.Scanner;

import in.ineuron.dao.CricketerDaoLayer;
import in.ineuron.model.CricketerBO;

public class TestApp {
	
	public static void main(String[] args) {		
		CricketerDaoLayer cric=new CricketerDaoLayer();
		cric.getDatas();
	}

}
