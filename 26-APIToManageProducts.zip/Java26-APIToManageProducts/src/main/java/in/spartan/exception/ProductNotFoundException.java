package in.spartan.exception;

public class ProductNotFoundException extends Exception {

	public ProductNotFoundException(String arg0) {
		super(arg0);
	
	}

	
}
