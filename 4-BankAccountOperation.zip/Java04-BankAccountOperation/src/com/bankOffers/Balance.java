package com.bankOffers;

import com.server.Server;

public class Balance extends Server {
	
	static void afterWithdraw(double amount)
	{
		bankBalance=bankBalance-amount;
	}
	static void afterDeposit(double amount)
	{
		bankBalance=bankBalance+amount;
	}
	
	
	@Override
	public void verifyUser() {
		if(uid==id && upw==pw)
		{
			System.out.println("Your Bank Balance fetched Successfully");
			System.out.println(bankBalance);
		}
		else
		{
			System.out.println("Login credentials are wrong pls check....");
		}
		
	}
	

}
