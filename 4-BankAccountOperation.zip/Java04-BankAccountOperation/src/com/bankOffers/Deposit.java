package com.bankOffers;

import java.util.Scanner;

import com.server.Server;

public class Deposit extends Server{

	@Override
	public void verifyUser() {
		Scanner s=new Scanner(System.in);
		if(uid==id && upw==pw)
		{
			System.out.println("Enter the amount to be deposited");
			amount=s.nextDouble();

			System.out.println("Your amount has been Deposited successfully ");
			Balance.afterDeposit(amount);
			System.out.println("Thank you");
			System.out.println("Your bank Balance is");
			System.out.println(bankBalance);
		}else {
			System.out.println("Login credentials are wrong pls check....");
		}
		
	}
	
	
	

}
