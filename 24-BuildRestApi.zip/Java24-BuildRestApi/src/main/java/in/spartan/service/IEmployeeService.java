package in.spartan.service;

import in.spartan.model.Employee;

public interface IEmployeeService {

	public String saveEmployee(Employee employee);
}
