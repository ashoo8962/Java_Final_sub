package in.ineuron.daofactory;

import in.ineuron.dao.BlogPostDaoImpl;
import in.ineuron.dao.IBlogPostDao;

public class BlogPostDaoFactory {
	
	private BlogPostDaoFactory()
	{
		
	}
	static IBlogPostDao blogPostDao=null;
	public static IBlogPostDao getBlogPostDao()
	{
		blogPostDao=new BlogPostDaoImpl();
		return blogPostDao;
		
	}

}
