package in.crud.daoFactory;

import in.crud.persistencelayer.IStudentDao;
import in.crud.persistencelayer.StudentDaoImpl;

public class StudentDaoFactory {
	
	private StudentDaoFactory()
	{
		
	}
	static IStudentDao studentDao=null;
	public static IStudentDao getStudentDao()
	{
		studentDao=new StudentDaoImpl();
		return studentDao;
		
	}

}
