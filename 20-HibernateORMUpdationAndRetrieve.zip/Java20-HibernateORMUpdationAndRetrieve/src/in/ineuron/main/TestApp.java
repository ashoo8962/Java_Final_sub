package in.ineuron.main;

import java.util.Scanner;

import in.ineuron.dao.CricketerDaoLayer;
import in.ineuron.model.CricketerBO;

public class TestApp {
	
	public static void main(String[] args) {
		
		CricketerDaoLayer cric=new CricketerDaoLayer();
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the Id :: ");
		Integer id = scanner.nextInt();

		CricketerBO cricketer = cric.getDatas(id);
		
		if(cricketer!=null) {
		
			CricketerBO bo=new CricketerBO();
			System.out.println("Cricketer Id is :: "+cricketer.getId());
			
			bo.setId(cricketer.getId());
			
			System.out.print("Name :: "+cricketer.getName()+"  Enter the new name :: ");
			String newName = scanner.next();
			if(newName.equals("") || newName=="")
				bo.setName(cricketer.getName());
			else
				bo.setName(newName);
	        
			
			System.out.print("Franchise :: "+cricketer.getFranchise()+"  Enter the new franchise :: ");
			String newFranchise= scanner.next();
			if(newFranchise.equals("") || newFranchise=="")
				bo.setFranchise(cricketer.getFranchise());
			else
				bo.setFranchise(newFranchise);
			
			
			System.out.print("Team :: "+cricketer.getTeam()+"  Enter the new team:: ");
			String newTeam = scanner.next();
			if(newTeam.equals("") || newTeam=="")
				bo.setTeam(cricketer.getTeam());
			else
			    bo.setTeam(newTeam);
			
			cric.updateCricketer(bo);
		}
		else {
			System.out.println("Record Not available for given id ::"+id);
		}

		
	
		
		
	}

}
