package in.main;

import java.util.Scanner;

import in.handler.HandlingException;

public class TestApp {
	
	public static void main(String[] args) {
		
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter any value");
		int num=scanner.nextInt();
		
		try {
			HandlingException.checkPositiveOrNegative(num);
		}catch(Exception e) {
		   System.out.println("You have entered negative number. And so the exception is handled");
		}
		
		scanner.close();
	}

}
